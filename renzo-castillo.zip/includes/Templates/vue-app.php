<?php
/** Template VueApp
 *
 * @package renzo-castillo *
 */

?>
<noscript>Sorry, this page requires JavaScript to function properly. Please enable JavaScript in your browser and try
	again.
</noscript>
<div class="wrap">
	<div id="renzo-castillo-app" v-cloak></div>
</div>
